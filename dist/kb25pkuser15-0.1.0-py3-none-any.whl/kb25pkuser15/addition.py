# kb25pkuser15/addition.py
def add(a, b):
   return a + b

